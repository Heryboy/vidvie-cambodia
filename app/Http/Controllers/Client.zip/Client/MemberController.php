<?php

namespace App\Http\Controllers\Client;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Admin\Language;
use App\Models\Admin\UsefulLink;
use App\Models\Admin\Member;
use App\Models\Admin\BusinessType;
use App\Models\Admin\MemberType;
use DB;
use App\user;
use Mail;
use Validator;
use Auth;
use App;
use Session;
use Input;

class MemberController extends Controller
{

  //current_members 
  public function current_members(){
    $members = Member::all();
    $members = Member::all();
    $BusinessType = BusinessType::lists('name','id');
    $MemberType = MemberType::lists('name','id');
    return view('Client.members.member')
              ->with('members',$members)
              ->with('BusinessType',$BusinessType)
              ->with('MemberType',$MemberType);
  }

  //member_detail 
  public function member_detail($id,$member_name){
    $members = Member::find($id);
    return view('Client.members.member_detail')->with('members',$members);
  }

  //member_benefit 
  public function member_benefit(){
    return view('Client.members.member_benefit');
  }

  //how_to_be_our_member 
  public function how_to_be_our_member(){
    return view('Client.members.how_to_be_our_member');
  }

}   
